package com.example.lab7_icon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
