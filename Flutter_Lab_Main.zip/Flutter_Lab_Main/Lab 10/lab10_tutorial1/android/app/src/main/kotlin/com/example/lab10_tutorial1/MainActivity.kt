package com.example.lab10_tutorial1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
