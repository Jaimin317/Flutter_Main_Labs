package com.example.lab9_tutorial2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
